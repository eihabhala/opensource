from dotenv import load_dotenv
import streamlit as st
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.callbacks import get_openai_callback
from langchain.agents import create_csv_agent
from langchain.llms import OpenAI


def ask_your_pdf():
    """Ask questions about a PDF file."""
    # Upload file
    pdf = st.file_uploader("Upload your PDF", type="pdf", key="pdf_uploader")

    # Extract the text
    if pdf is not None:
        pdf_reader = PdfReader(pdf)
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text()

        # Split into chunks
        text_splitter = CharacterTextSplitter(
            separator="\n",
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )
        chunks = text_splitter.split_text(text)

        # Create embeddings
        embeddings = OpenAIEmbeddings()
        knowledge_base = FAISS.from_texts(chunks, embeddings)

        # Show user input
        user_question = st.text_input("What do you want to know?", key="pdf_question")
        if user_question:
            docs = knowledge_base.similarity_search(user_question)

            llm = OpenAI()
            chain = load_qa_chain(llm, chain_type="stuff")
            with get_openai_callback() as cb:
                response = chain.run(input_documents=docs, question=user_question)
                print(cb)

            st.write(response)


def ask_your_csv():
    """Ask questions about a CSV file."""
    # Prompt the user for the name of the CSV file they want to read
    csv_file = st.file_uploader("Upload your CSV", type="csv", key="csv_uploader")

    if csv_file is not None:
        openai = OpenAI(temperature=0.9)
        agent = create_csv_agent(openai, csv_file, verbose=False)

        # Prompt the user for their query
        user_query = st.text_input("Enter your query:", key="csv_query")

        # Use the agent to execute the user's query and print the results
        if user_query:
            st.write("Executing query...")
            with get_openai_callback() as cb:
                response = agent.run(user_query)
                print(cb)
            st.write(response)


def main():
    """Main function to run the Streamlit app."""
    load_dotenv()
    st.set_page_config(page_title="Ask your PDF or CSV")
    st.header("ASK YOUR PDF OR CSV! 🤓")

    # Show user input
    user_input = st.selectbox("What type of file do you want to ask questions about?", ["PDF", "CSV"], key="file_type")

    if user_input == "PDF":
        ask_your_pdf()
    elif user_input == "CSV":
        ask_your_csv()


if __name__ == '__main__':
    main()
